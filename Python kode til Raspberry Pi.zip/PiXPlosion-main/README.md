# PiXplosion
A repo to contain files concerning our Raspberry PI 5 and Sense HAT.
