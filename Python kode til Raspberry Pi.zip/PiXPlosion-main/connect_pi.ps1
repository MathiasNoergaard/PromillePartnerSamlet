# To run PowerShell script type: .\connect_pi.ps1
$username = "pp"
$hostname = "PromillePartner.local"
ssh "$username@$hostname"