export const data = () => ({
    cocktail: null,
  });
  