export default {
    mounted() {
      console.log("mounted")
      // this.calculate();
      this.getDrinks();
    }
  };