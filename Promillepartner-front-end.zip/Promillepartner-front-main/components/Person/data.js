export const data = () => ({
  
  errorMessage: null,
  searchPersonID: 1,
  personData: {},
      gender: "male",
      age: 18,
      weight: 70,


    shownRecords: [],
    shownPerson: {},
    enteredGender: "male",
    enteredWeight: 0,
    enteredAge: 0,
    id: 0,
    addData: {
      gender: true,
      weight: 0,
      age: 0
    },
    creationMessage: "",
    addMessage: ""
  });
  