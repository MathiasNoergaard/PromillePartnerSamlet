export const data = () => ({
    latestPromilleReading: null,
    allPromilleReadings: [],
    normalTimestamp: ""
});