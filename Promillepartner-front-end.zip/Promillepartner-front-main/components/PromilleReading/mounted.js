export const mountedLogic = {
    mounted() {
      console.log("mounted")
      // this.calculate();
      this.getLatestPiReading();
      
    }
  };